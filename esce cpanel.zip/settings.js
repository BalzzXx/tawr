const chalk = require('chalk')

//Settings
global.owner = ["6281227811256"]
global.bot = "6281227811256"
global.ownername = 'BalzzX';
global.namabot = 'BalzzX-Cpanel';
global.botversion = "V1"
global.linkgc = "https://chat.whatsapp.com/GP7o3NWsuVWLcp5LXChKY3"
global.idGc = "120363419635247304@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029VajRk18EgGfKmRLvlC0O"
global.idSaluran = "120363334848410803@newsletter"
global.namaSaluran = global.ownername + " | Saluran WhatsApp"
global.simbol = "⬡"

//Thumbnail
global.imgthumb = "https://files.catbox.moe/0c9g1i.jpg"

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://_"
global.apikey = "ptla_" //ptla
global.capikey = "ptlc_" //ptlc

//Log Di Perbarui
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})